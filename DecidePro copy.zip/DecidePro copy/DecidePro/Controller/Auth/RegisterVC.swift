//
//  RegisterVC.swift
//  decidePro
//
//  Created by Osiano Momoh on 10/05/2022.
//

import UIKit

class RegisterVC: UIViewController {
    //MARK: - Properties
    
    
    //MARK: - IBOutlets
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var tfConfirmPassword: UITextField!
    
    
    //MARK: - View Controller Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLayout()
        setupBinding()
        // Do any additional setup after loading the view.
    }
    
    //MARK: - Custom Methods
    private func setLayout(){
        
    }
    
    private func setupBinding(){
        
    }
    
    //MARK: - IBActions
    @IBAction func btnActionRegister(_ sender: UIButton) {
    }
    
    @IBAction func btnActionSignin(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
