//
//  UpdateWheelOptionsVC.swift
//  decidePro
//
//  Created by Osiano Momoh on 10/05/2022.
//

import UIKit

class UpdateWheelOptionsVC: UIViewController {

    @IBOutlet weak var tfOptionOne: UITextField!
    @IBOutlet weak var tfOptionTwo: UITextField!
    @IBOutlet weak var tfOptionThree: UITextField!
    @IBOutlet weak var tfOptionFour: UITextField!
    @IBOutlet weak var tfOptionFive: UITextField!
    @IBOutlet weak var tfOptionSix: UITextField!
    @IBOutlet weak var tfOptionSeven: UITextField!
    @IBOutlet weak var tfOptionEight: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = UserDefaults.standard
        let wheelDataArray = defaults.stringArray(forKey: "SaveWheelData") ?? [String]()
        tfOptionOne.text = wheelDataArray[0]
        tfOptionTwo.text = wheelDataArray[1]
        tfOptionThree.text = wheelDataArray[2]
        tfOptionFour.text = wheelDataArray[3]
        tfOptionFive.text = wheelDataArray[4]
        tfOptionSix.text = wheelDataArray[5]
        tfOptionSeven.text = wheelDataArray[6]
        tfOptionEight.text = wheelDataArray[7]
        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    //MARK: - IBActions
    
    @IBAction func btnActionUpdate(_ sender: UIButton) {
        if (tfOptionOne.text?.isEmpty ?? true) || (tfOptionTwo.text?.isEmpty ?? true) || (tfOptionThree.text?.isEmpty ?? true) || (tfOptionFour.text?.isEmpty ?? true) || (tfOptionFive.text?.isEmpty ?? true) || (tfOptionSix.text?.isEmpty ?? true) || (tfOptionSeven.text?.isEmpty ?? true) || (tfOptionEight.text?.isEmpty ?? true){
            self.alert(message: "Please add all the options in the given fields", title: "DicePro")
        }else{
            
            let array = [tfOptionOne.text, tfOptionTwo.text, tfOptionThree.text, tfOptionFour.text, tfOptionFive.text, tfOptionSix.text, tfOptionSeven.text, tfOptionEight.text]
            let defaults = UserDefaults.standard
            defaults.set(array, forKey: "SaveWheelData")
//            self.alertWithPop(message: "Wheel Data Updated Successfully", title: "DicePro")
            self.tabBarController?.navigationController?.popViewController(animated: true)
            for controller in self.navigationController!.viewControllers as Array {
                if controller.isKind(of: StartOverVC.self) {
                    self.navigationController!.popToViewController(controller, animated: true)
                    break
                }
            }
        }
    }
    
}
