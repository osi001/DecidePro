//
//  CreateWheelVC.swift
//  decidePro
//
//  Created by Osiano Momoh on 10/05/2022.
//
import UIKit

class CreateWheelVC: UIViewController {
    //MARK: - Properties
    
    
    //MARK: - IBOutlets
    
    
    //MARK: - View Controller Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLayout()
        setupBinding()
        // Do any additional setup after loading the view.
    }
    
    //MARK: - Custom Methods
    private func setLayout(){
        
    }
    
    private func setupBinding(){
        
    }
    
    //MARK: - IBActions
    @IBAction func btnActionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnActionAddToSiri(_ sender: UIButton) {
        
    }
    
    
}
