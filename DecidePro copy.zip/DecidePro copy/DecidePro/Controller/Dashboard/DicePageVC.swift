//
//  DicePageVC.swift
//  decidePro
//
//  Created by Osiano Momoh on 10/05/2022.
//

import UIKit

class DicePageVC: UIViewController {
    //MARK: - Properties
    
    
    //MARK: - IBOutlets
    
    
    //MARK: - View Controller Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLayout()
        setupBinding()
        // Do any additional setup after loading the view.
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touchCount = touches.count
        let touch = touches.first
        let tapCount = touch!.tapCount
        
        print("touchesMoved \(touchCount) touches \(tapCount) taps")
        
        if let eventObj = event {
            for predictedTouch in eventObj.predictedTouches(for: touch!)! {
                let point = predictedTouch.location(in: self.view)
                print("Predicted location X = \(point.x), Y = \(point.y)")
            }
            print("============")
        }
    }
    
    //MARK: - Custom Methods
    private func setLayout(){
        self.view.isMultipleTouchEnabled = true
    }
    
    private func setupBinding(){
        
    }
    
    //MARK: - IBActions
    @IBAction func btnActionMenu(_ sender: UIButton) {
        let vc = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(withIdentifier: "ChooserDetailVC")
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

