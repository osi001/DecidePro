//
//  AddWheelVC.swift
//  decidePro
//
//  Created by Osiano Momoh on 10/05/2022.
//
import UIKit

class AddWheelVC: UIViewController {
    //MARK: - Properties
    
    
    //MARK: - IBOutlets
    
    
    //MARK: - View Controller Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLayout()
        setupBinding()
        // Do any additional setup after loading the view.
    }
    
    //MARK: - Custom Methods
    private func setLayout(){
        
    }
    
    private func setupBinding(){
        
    }
    
    //MARK: - IBActions
    @IBAction func btnActionCreateNew(_ sender: UIButton) {
        let vc = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(withIdentifier: "CreateWheelVC")
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnActionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
