//
//  HomeVC.swift
//  decidePro
//
//  Created by Osiano Momoh on 10/05/2022.
//
import UIKit
import AVFoundation
import TTFortuneWheel

class HomeVC: UIViewController, CAAnimationDelegate, AVAudioPlayerDelegate {
    //MARK: - Properties
    var arrayIndex = [0,1,2,3,4,5,6,7]
    
    //MARK: - IBOutlets
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var btnSpinFlip: UIButton!
//    var spinningWheel: TTFortuneWheel?
    @IBOutlet var spinningWheel: TTFortuneWheel!
    
    //MARK: - View Controller Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBinding()
        setLayout()
        // Do any additional setup after loading the view.
    }
    
    override func becomeFirstResponder() -> Bool {
        return true
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake{
            spinningWheel?.startAnimating()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                self.spinningWheel?.startAnimating(fininshIndex: self.arrayIndex.randomElement() ?? 0) { (finished) in
                    print(finished)
                }
            }
        }
    }
    
    //MARK: - Custom Methods
    private func setLayout(){
        let defaults = UserDefaults.standard
        let wheelDataArray = defaults.stringArray(forKey: "SaveWheelData") ?? [String]()
        
        spinningWheel?.endEditing((self.view != nil))
        
        let slices = [ FortuneWheelSlice(title: wheelDataArray[0]),
                       FortuneWheelSlice(title: wheelDataArray[1]),
                       FortuneWheelSlice(title: wheelDataArray[2]),
                       FortuneWheelSlice(title: wheelDataArray[3]),
                       FortuneWheelSlice(title: wheelDataArray[4]),
                       FortuneWheelSlice(title: wheelDataArray[5]),
                       FortuneWheelSlice(title: wheelDataArray[6]),
                       FortuneWheelSlice(title: wheelDataArray[7])]
        spinningWheel?.slices = slices
        
        spinningWheel.layoutSubviews()
        self.spinningWheel?.equalSlices = true
        self.spinningWheel?.frameStroke.width = 0
        self.spinningWheel?.titleRotation = CGFloat.pi
        self.spinningWheel?.slices.enumerated().forEach { (pair) in
            let slice = pair.element as! FortuneWheelSlice
            let offset = pair.offset
            switch offset % 4 {
            case 0: slice.style = .dark
            case 1: slice.style = .light
            case 2: slice.style = .dark
            case 3: slice.style = .light
            default: slice.style = .dark
            }
        }
        self.spinningWheel?.backgroundColor = .clear
    }
    
    private func setupBinding(){
        
    }
    
    //MARK: - IBActions
    
    @IBAction func btnActionMenu(_ sender: UIButton) {
//        let vc = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(withIdentifier: "WheelDetailVC")
//        self.navigationController?.pushViewController(vc, animated: true)
        let vc = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(withIdentifier: "UpdateWheelOptionsVC")
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnActionSpin(_ sender: UIButton) {
        spinningWheel?.startAnimating()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.spinningWheel?.startAnimating(fininshIndex: self.arrayIndex.randomElement() ?? 0) { (finished) in
                print(finished)
            }
        }
    }
    
}
