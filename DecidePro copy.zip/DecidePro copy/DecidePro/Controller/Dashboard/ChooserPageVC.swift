//
//  ChooserPageVC.swift
//  decidePro
//
//  Created by Osiano Momoh on 10/05/2022.
//

import UIKit
import AVFoundation

class ChooserPageVC: UIViewController, CAAnimationDelegate, AVAudioPlayerDelegate {
    //MARK: - Properties
    let diceArray = [UIImage.init(named: "dice1"), UIImage.init(named: "dice2"), UIImage.init(named: "dice3"), UIImage.init(named: "dice4"), UIImage.init(named: "dice5"), UIImage.init(named: "dice6")]
    
    let coinProvider = CoinSideProvider()
    let colourProvider = BackgroundColourProvider()
    var flipButtonSound = URL(fileURLWithPath: Bundle.main.path(forResource: "switchSound", ofType: "mp3")!)
    var coinImageSound = URL(fileURLWithPath: Bundle.main.path(forResource: "tapSound", ofType: "mp3")!)
    var audioPlayerButton = AVAudioPlayer()
    var audioPlayerImage = AVAudioPlayer()
    var previousColour: UIColor?
    
    //MARK: - IBOutlets
    @IBOutlet weak var diceImgOne: UIImageView!
    @IBOutlet weak var diceImgTwo: UIImageView!
    
    @IBOutlet weak var coinContainerView: UIView!
    @IBOutlet weak var coinImgView: UIImageView!
    
    @IBOutlet weak var btnFlipSpin: UIButton!
    
    
    
    //MARK: - View Controller Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLayout()
        setupBinding()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if UserDefaults.standard.value(forKey: "isCoin") as? Bool == true{
            coinContainerView.isHidden = false
            btnFlipSpin.isHidden = false
        }else{
            coinContainerView.isHidden = true
            btnFlipSpin.isHidden = true
        }
    }
    
    override func becomeFirstResponder() -> Bool {
        return true
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake{
            if UserDefaults.standard.value(forKey: "isCoin") as? Bool == false{
                diceMooveRight() // animation des dés rotation, taille, déplaement
                animAttackDice() // anim les dés a l'aide du dictionnaire d'image
                UIButton().flash() // anim le bouton
                rollDice()
            }else{
                btnFlipSpin.pulsate()
                btnFlipSpin.isEnabled = false
                audioPlayerButton.play()
                // Setting the random colour and making sure the previous colour is not repeated consecutively.
                var randomColour = colourProvider.randomColour()
                while previousColour == randomColour {
                    randomColour = colourProvider.randomColour()
                }
                previousColour = randomColour
    //            view.backgroundColor = randomColour
    //            btnSpinFlip.tintColor = randomColour
                coinImgView.image = #imageLiteral(resourceName: "coinSide")
                audioPlayerButton.delegate = self
                func rotateCoin() {
                    let rotateAnimation = CABasicAnimation()
                    rotateAnimation.keyPath = "transform.rotation"
                    rotateAnimation.fromValue = 0
                    rotateAnimation.toValue = 4 * Double.pi
                    rotateAnimation.duration = 0.4
                    rotateAnimation.isRemovedOnCompletion = false
                    rotateAnimation.delegate = self
                    
                    coinImgView.layer.add(rotateAnimation,
                                 forKey: nil)
                }
                rotateCoin()
                
                func animationDidStop(_ anim: CABasicAnimation, finished flag: Bool) {
                    coinImgView.layer.removeFromSuperlayer()
                }

            }
        }
    }
    
    //MARK: - Custom Methods
    private func setLayout(){
        diceImgOne.image = UIImage.init(named: "dice\(randomDice())")
        diceImgTwo.image = UIImage.init(named: "dice\(randomDice())")
        
        coinImgView.image = #imageLiteral(resourceName: "coinSide")
        
        audioPlayerButton = try! AVAudioPlayer(contentsOf: flipButtonSound)
        audioPlayerImage = try! AVAudioPlayer(contentsOf: coinImageSound)
        
        // Setting the tap gesture to the coinImageView.
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        coinImgView.isUserInteractionEnabled = true
        coinImgView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    private func setupBinding(){
        
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        audioPlayerImage.play()
        audioPlayerImage.delegate = self
        _ = tapGestureRecognizer.view as! UIImageView
        // This is the bounce down animation.
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 5, options: UIView.AnimationOptions.allowUserInteraction, animations: { () -> Void in
            self.coinImgView.transform = CGAffineTransform(scaleX: 0.7, y: 0.7)
        }, completion: nil)
        
        // This is the bounce up animation, runs at the same time as bounce down.
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 5, options: UIView.AnimationOptions.allowUserInteraction, animations: { () -> Void in
            
            self.coinImgView.transform = CGAffineTransform(scaleX: 1, y: 1)
        }, completion: nil)
    }
    
    func randomDice() -> Int {
        return Int.random(in: 1...6)
    }
    
    func rollDice(){
        diceImgOne.image = UIImage.init(named: "dice\(randomDice())")
        diceImgTwo.image = UIImage.init(named: "dice\(randomDice())")
    }
    
    func animAttackDice(){
        animateDice(dice: diceImgOne, isAttack: true)
        animateDice(dice: diceImgTwo, isAttack: true)
    }
    
    func animateDice(dice: UIImageView, isAttack: Bool){
        dice.animationImages = (diceArray.shuffled() as! [UIImage])
        dice.animationDuration = 1
        dice.animationRepeatCount = randomDice()
        dice.startAnimating()
    }
    
    func mooveDiceToRight (){
        UIView.animate(withDuration: 0.5) {
            self.diceImgOne.center.x += 50
            self.diceImgTwo.center.x += 50
        }
    }
    
    func diceMooveRight(){
        UIView.animate(withDuration: 6, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 3, options: [], animations: {
            self.diceImgOne.transform = CGAffineTransform(scaleX: 5, y: 5) //  augmente la taille des dés
            self.diceImgOne.transform = CGAffineTransform(rotationAngle: CGFloat.pi) // rotation des dés
            self.diceImgOne.transform = CGAffineTransform(translationX: 50, y: 0) // déplacement de 50 sur axe x
            
            self.diceImgTwo.transform = CGAffineTransform(scaleX: 5, y: 5)
            self.diceImgTwo.transform = CGAffineTransform(rotationAngle: CGFloat.pi)
            self.diceImgTwo.transform = CGAffineTransform(translationX: 50, y: 0)
            
        }) {
            finished in // quand l'animation est fini retour a la position d'origine
            self.diceImgOne.transform = .identity
            self.diceImgTwo.transform = .identity
        }
    }
    
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        coinImgView.image = coinProvider.randomCoinSide()
        btnFlipSpin.isEnabled = true
    }
    
    //MARK: - IBActions
    @IBAction func btnActionMenu(_ sender: UIButton) {
        let vc = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(withIdentifier: "DiceDetailVC")
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnActionFlip(_ sender: UIButton) {
        if UserDefaults.standard.value(forKey: "isCoin") as? Bool == true{
            sender.pulsate()
            btnFlipSpin.isEnabled = false
            audioPlayerButton.play()
            // Setting the random colour and making sure the previous colour is not repeated consecutively.
            var randomColour = colourProvider.randomColour()
            while previousColour == randomColour {
                randomColour = colourProvider.randomColour()
            }
            previousColour = randomColour
//            view.backgroundColor = randomColour
//            btnSpinFlip.tintColor = randomColour
            coinImgView.image = #imageLiteral(resourceName: "coinSide")
            audioPlayerButton.delegate = self
            func rotateCoin() {
                let rotateAnimation = CABasicAnimation()
                rotateAnimation.keyPath = "transform.rotation"
                rotateAnimation.fromValue = 0
                rotateAnimation.toValue = 4 * Double.pi
                rotateAnimation.duration = 0.4
                rotateAnimation.isRemovedOnCompletion = false
                rotateAnimation.delegate = self
                
                coinImgView.layer.add(rotateAnimation,
                             forKey: nil)
            }
            rotateCoin()
            
            func animationDidStop(_ anim: CABasicAnimation, finished flag: Bool) {
                coinImgView.layer.removeFromSuperlayer()
            }
        }
    }
}
