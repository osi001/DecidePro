//
//  DiceDetailVC.swift
//  decidePro
//
//  Created by Osiano Momoh on 10/05/2022.
//

import UIKit

class DiceDetailVC: UIViewController {
    //MARK: - Properties
    var numbers:[String] = ["1", "2", "3", "4", "5"]
    
    //MARK: - IBOutlets
    @IBOutlet var pickerView: UIView!
    @IBOutlet weak var numberPicker: UIPickerView!
    
    @IBOutlet weak var tfSaveResult: UITextField!
    
    //MARK: - View Controller Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLayout()
        setupBinding()
        // Do any additional setup after loading the view.
    }
    
    //MARK: - Custom Methods
    private func setLayout(){
        setupPickerView()
    }
    
    private func setupBinding(){
        tfSaveResult.delegate = self
    }
    
    private func setupPickerView(){
        tfSaveResult.inputView = self.pickerView
        numberPicker.dataSource = self
        numberPicker.delegate = self
    }
    

    //MARK: - IBActions
    @IBAction func btnActionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnActionDone(_ sender: UIButton) {
        
    }
    
    @IBAction func btnActionCoin(_ sender: UIButton) {
        UserDefaults.standard.set(true, forKey: "isCoin")
    }
    
    @IBAction func btnActionDice(_ sender: UIButton) {
        UserDefaults.standard.set(false, forKey: "isCoin")
    }
    
    
}


//MARK: - PickerView Delegate Methods
extension DiceDetailVC: UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate{
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return numbers.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return numbers[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        tfSaveResult.text = numbers[row]
    }
}
